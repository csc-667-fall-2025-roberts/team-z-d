module.exports = {
  up: (pgm) => {
    pgm.createTable("messages", {
      id: "id",

      game_id: {
        type: "integer",
        notNull: true,
        references: '"games"',
        onDelete: "CASCADE",
      },

      user_id: {
        type: "integer",
        notNull: true,
        references: '"users"',
        onDelete: "CASCADE",
      },

      message: {
        type: "text",
        notNull: true,
      },

      created_at: {
        type: "timestamptz",
        notNull: true,
        default: pgm.func("now()"),
      },
    });

    pgm.createIndex("messages", "game_id");
    pgm.createIndex("messages", "user_id");
    pgm.createIndex("messages", ["game_id", "created_at"]);
  },

  down: (pgm) => {
    pgm.dropTable("messages");
  },
};
