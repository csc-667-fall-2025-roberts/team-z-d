module.exports = {
  up: (pgm) => {
    pgm.createTable("games", {
      id: "id",

      name: {
        type: "varchar(50)",
        notNull: true,
      },

      created_by: {
        type: "integer",
        notNull: true,
        references: '"users"',
        onDelete: "CASCADE",
      },

      state: {
        type: "varchar(20)",
        notNull: true,
        default: "waiting",
      },

      max_players: {
        type: "integer",
        notNull: true,
      },

      created_at: {
        type: "timestamptz",
        notNull: true,
        default: pgm.func("now()"),
      },
    });

    pgm.addConstraint("games", "games_state_check", {
      check: "state in ('waiting', 'in_progress', 'finished')",
    });

    pgm.createIndex("games", "created_by");
    pgm.createIndex("games", "state");
    pgm.createIndex("games", ["state", "created_at"]);
  },

  down: (pgm) => {
    pgm.dropTable("games");
  },
};
