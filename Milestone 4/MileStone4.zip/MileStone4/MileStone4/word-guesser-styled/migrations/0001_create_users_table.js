module.exports = {
  up: (pgm) => {
    pgm.createTable("users", {
      id: "id", // serial primary key

      username: {
        type: "varchar(50)",
        notNull: true,
      },

      email: {
        type: "varchar(255)",
        notNull: true,
      },

      password_hash: {
        type: "text",
        notNull: true,
      },

      created_at: {
        type: "timestamptz",
        notNull: true,
        default: pgm.func("now()"),
      },
    });

    pgm.addConstraint("users", "users_email_unique", {
      unique: ["email"],
    });

    pgm.addConstraint("users", "users_username_unique", {
      unique: ["username"],
    });

    pgm.createIndex("users", "email");
    pgm.createIndex("users", "username");
  },

  down: (pgm) => {
    pgm.dropTable("users");
  },
};
