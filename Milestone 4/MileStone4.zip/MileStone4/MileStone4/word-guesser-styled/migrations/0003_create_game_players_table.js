module.exports = {
  up: (pgm) => {
    pgm.createTable("game_players", {
      game_id: {
        type: "integer",
        notNull: true,
        references: '"games"',
        onDelete: "CASCADE",
      },

      user_id: {
        type: "integer",
        notNull: true,
        references: '"users"',
        onDelete: "CASCADE",
      },

      joined_at: {
        type: "timestamptz",
        notNull: true,
        default: pgm.func("now()"),
      },
    });

    pgm.addConstraint("game_players", "game_players_pkey", {
      primaryKey: ["game_id", "user_id"],
    });

    pgm.createIndex("game_players", "game_id");
    pgm.createIndex("game_players", "user_id");
  },

  down: (pgm) => {
    pgm.dropTable("game_players");
  },
};
