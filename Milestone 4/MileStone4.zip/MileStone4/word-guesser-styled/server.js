const express = require("express");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;

// View engine setup
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));

// Static files
app.use("/public", express.static(path.join(__dirname, "public")));
app.use(express.urlencoded({ extended: true }));

// Fake in-memory data just for demo
const fakeUser = { id: 1, username: "Miguel" };

let fakeGames = [
  {
    id: 1,
    name: "Miguel's Word Room",
    host_username: "Miguel",
    player_count: 2,
    max_players: 6,
    state: "waiting",
  },
  {
    id: 2,
    name: "Chill Guessers",
    host_username: "Ana",
    player_count: 4,
    max_players: 6,
    state: "in-progress",
  },
];

let fakeMessages = [
  { username: "Miguel", message: "Welcome to the lobby!" },
  { username: "Ana", message: "Who wants to play a quick round?" },
];

// Routes
app.get("/", (req, res) => {
  res.redirect("/auth/login");
});

// Auth
app.get("/auth/login", (req, res) => {
  res.render("login", { error: null });
});

app.post("/auth/login", (req, res) => {
  // For demo, just redirect to lobby
  res.redirect("/lobby");
});

app.post("/auth/logout", (req, res) => {
  res.redirect("/auth/login");
});

app.get("/auth/signup", (req, res) => {
  res.render("signup", { error: null });
});

app.post("/auth/signup", (req, res) => {
  // For demo, just redirect to lobby
  res.redirect("/lobby");
});

// Lobby
app.get("/lobby", (req, res) => {
  res.render("lobby", {
    user: fakeUser,
    games: fakeGames,
    messages: fakeMessages,
  });
});

app.post("/games", (req, res) => {
  const { name, max_players } = req.body;
  const id = fakeGames.length + 1;
  fakeGames.push({
    id,
    name: name || `Game ${id}`,
    host_username: fakeUser.username,
    player_count: 1,
    max_players: parseInt(max_players || 6, 10),
    state: "waiting",
  });
  res.redirect("/lobby");
});

// Game page
app.get("/games/:id", (req, res) => {
  const id = parseInt(req.params.id, 10);
  const game = fakeGames.find((g) => g.id === id) || fakeGames[0];

  const host = { id: 1, username: game.host_username };
  const players = [
    host,
    { id: 2, username: "PlayerTwo" },
    { id: 3, username: "PlayerThree" },
  ];

  res.render("game", {
    game,
    host,
    players,
  });
});

// Messages (demo only)
app.post("/messages", (req, res) => {
  const { message } = req.body;
  if (message && message.trim()) {
    fakeMessages.push({ username: fakeUser.username, message: message.trim() });
  }
  res.redirect("/lobby");
});

// Error demo route
app.get("/error", (req, res) => {
  res.status(500).render("error", {
    status: 500,
    message: "This is a demo error page.",
  });
});

// 404 handler
app.use((req, res) => {
  res.status(404).render("error", {
    status: 404,
    message: "Page not found.",
  });
});

app.listen(PORT, () => {
  console.log(`Word Guesser styled demo running at http://localhost:${PORT}`);
});
